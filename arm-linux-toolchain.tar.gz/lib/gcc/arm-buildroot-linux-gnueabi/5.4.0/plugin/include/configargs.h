/* Generated automatically. */
static const char configuration_arguments[] = "./configure --prefix=/home/jinhuawu/buildroot/output/host/usr --sysconfdir=/home/jinhuawu/buildroot/output/host/etc --enable-static --target=arm-buildroot-linux-gnueabi --with-sysroot=/home/jinhuawu/buildroot/output/host/usr/arm-buildroot-linux-gnueabi/sysroot --disable-__cxa_atexit --with-gnu-ld --disable-libssp --disable-multilib --with-gmp=/home/jinhuawu/buildroot/output/host/usr --with-mpc=/home/jinhuawu/buildroot/output/host/usr --with-mpfr=/home/jinhuawu/buildroot/output/host/usr --with-pkgversion='Buildroot 2017.02.1-g87864bb-dirty' --with-bugurl=http://bugs.buildroot.net/ --disable-libquadmath --enable-tls --disable-libmudflap --enable-threads --without-isl --without-cloog --disable-decimal-float --with-abi=aapcs-linux --with-cpu=cortex-a9 --with-fpu=vfpv3-d16 --with-float=softfp --with-mode=arm --enable-languages=c --with-build-time-tools=/home/jinhuawu/buildroot/output/host/usr/arm-buildroot-linux-gnueabi/bin --enable-shared --disable-libgomp";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "aapcs-linux" }, { "cpu", "cortex-a9" }, { "float", "softfp" }, { "mode", "arm" }, { "fpu", "vfpv3-d16" }, { "tls", "gnu" } };
